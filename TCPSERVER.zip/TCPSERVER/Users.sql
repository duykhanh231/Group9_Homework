create database Users;
use Users;

create table users
(
	UserID int IDENTITY(1,1) primary key,
	Username varchar(50),
	Password varchar(50),
	Email varchar(50),
	Fullname varchar(50),
	Birthday varchar(50)
);


select * from users;
delete users;
